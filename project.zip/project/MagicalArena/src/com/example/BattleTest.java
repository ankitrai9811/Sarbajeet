package com.example;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
public class BattleTest {
   @Test
   public void testPlayerInitialization() {
       Player player = new Player(50, 5, 10);
       assertEquals(50, player.getHealth());
       assertEquals(5, player.getStrength());
       assertEquals(10, player.getAttack());
   }
   @Test
   public void testHealthReduction() {
       Player player = new Player(50, 5, 10);
       player.reduceHealth(20);
       assertEquals(30, player.getHealth());
       player.reduceHealth(50);
       assertEquals(0, player.getHealth());
   }
   @Test
   public void testBattleSimulation() {
       Player playerA = new Player(50, 5, 10);
       Player playerB = new Player(100, 10, 5);
       Battle battle = new Battle(playerA, playerB);
       battle.fight();
       assertTrue(playerA.isAlive() || playerB.isAlive());
       assertFalse(playerA.isAlive() && playerB.isAlive());
   }
}