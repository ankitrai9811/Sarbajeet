package com.example;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		   Player playerA = new Player(50, 5, 10);
	       Player playerB = new Player(100, 10, 5);
	       Battle battle = new Battle(playerA, playerB);
	       battle.fight();
	}

}
