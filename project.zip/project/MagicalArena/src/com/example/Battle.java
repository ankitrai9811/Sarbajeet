package com.example;

import java.util.Random;

public class Battle {

    private Player player1;

    private Player player2;

    private Random dice;

    public Battle(Player player1, Player player2) {

        this.player1 = player1;

        this.player2 = player2;

        this.dice = new Random();

    }

    private int rollDice() {

        return dice.nextInt(6) + 1;

    }

    public void fight() {

        Player attacker = player1.getHealth() <= player2.getHealth() ? player1 : player2;

        Player defender = attacker == player1 ? player2 : player1;

        while (attacker.isAlive() && defender.isAlive()) {

            int attackRoll = rollDice();

            int defendRoll = rollDice();

            int attackDamage = attacker.getAttack() * attackRoll;

            int defendDamage = defender.getStrength() * defendRoll;

            int netDamage = Math.max(attackDamage - defendDamage, 0);

            defender.reduceHealth(netDamage);

            System.out.printf("%s attacks with roll %d, %s defends with roll %d, net damage %d. %s's health: %d\n",

                    attacker == player1 ? "Player A" : "Player B", attackRoll,

                    defender == player1 ? "Player A" : "Player B", defendRoll,

                    netDamage, defender == player1 ? "Player A" : "Player B",

                    defender.getHealth());

            if (!defender.isAlive()) {

                System.out.printf("%s wins!\n", attacker == player1 ? "Player A" : "Player B");

                break;

            }

            // Swap roles

            Player temp = attacker;

            attacker = defender;

            defender = temp;

        }

    }

}