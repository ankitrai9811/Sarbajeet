# Magical Arena
## Description
A simple simulation of a battle arena where two players fight until one of them dies. Each player has health, strength, and attack attributes. The battle is turn-based, and the damage dealt and defended is determined by rolling dice.
## How to Run
1. **Compile the main classes**:
   ```sh
   javac -d out src/main/java/com/example/*.java
   ```
2. **Run the main program**:
   ```sh
   java -cp out com.example.Main
   ```
3. **Run the tests**:
   - Download JUnit 5 JAR files and place them in a `lib` directory.
   - Compile the test classes:
       ```sh
       javac -cp "lib/*:out" -d out src/test/java/com/example/BattleTest.java
       ```
   - Run the tests:
       ```sh
       java -cp "lib/*:out" org.junit.platform.console.ConsoleLauncher --select-class com.example.BattleTest
       ```
## Classes
- `Player`: Represents a player in the arena with health, strength, and attack attributes.
- `Battle`: Manages the fight between two players.
- `Main`: The entry point of the program.
- `BattleTest`: Unit tests for the Battle and Player classes.
## Requirements
- Java 8 or higher
- JUnit 5 for running tests
## Author
Sarbajeet singh
Sarbajeetsingh219@gmail.com
9348565007